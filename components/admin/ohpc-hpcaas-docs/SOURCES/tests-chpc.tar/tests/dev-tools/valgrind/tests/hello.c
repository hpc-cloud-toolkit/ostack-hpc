#include <stdio.h>

int main() 
{
  const int i=1;
  printf("hello, i = %i\n",i);
  return 0;
}
  
